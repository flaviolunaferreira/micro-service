package com.thecoyote.funcionarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuncionariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
